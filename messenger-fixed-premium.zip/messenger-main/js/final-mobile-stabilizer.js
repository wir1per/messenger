
// ===== FINAL MOBILE STABILIZER =====

(function(){

function updateViewportHeight(){
  document.documentElement.style.setProperty(
    '--app-height',
    `${window.innerHeight}px`
  );
}

window.addEventListener('resize', updateViewportHeight);
window.addEventListener('orientationchange', updateViewportHeight);
updateViewportHeight();

// Fix typing ghost bug
let typingTimeout;

window.handleTypingState = function(isTyping){
  clearTimeout(typingTimeout);

  const indicator = document.querySelector('.typing-indicator');

  if(!indicator) return;

  if(isTyping){
    indicator.classList.add('active');

    typingTimeout = setTimeout(()=>{
      indicator.classList.remove('active');
    }, 1500);
  } else {
    indicator.classList.remove('active');
  }
};

// Better mobile scroll behavior
const messages = document.querySelector('.messages-container');

if(messages){
  messages.style.scrollBehavior = 'smooth';
}

})();
